﻿#Comando para ejecucion de app web  a carpeta target
 
java -jar dependency/jetty-runner.jar --port 8081 certification_proxy-1.1-SNAPSHOT